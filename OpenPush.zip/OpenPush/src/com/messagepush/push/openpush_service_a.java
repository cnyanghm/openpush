
package com.messagepush.push ;

import android.app.Service;

import android.content.Intent;
import android.content.Context;

import android.os.Binder;
import android.os.IBinder;
import android.os.Handler;

import android.util.Log;

public class openpush_service_a extends Service
{
	public void onCreate( )
	{
		super.onCreate( );

		new Handler().postDelayed(new Runnable()
			{
				public void run()
				{
					stopSelf( );
				}
			}, 500 );

	}

	public void onDestroy()
	{
		super.onDestroy();

		Intent i = new Intent( this, openpush_service.class) ;
		startService( i );
	}

	public IBinder onBind(Intent intent)
    {
        return null;
    }

 }


