
package com.messagepush.push;


import android.app.Activity;

import android.content.Intent;
import android.content.Context;

import android.os.Bundle;


public class main extends Activity
{

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		Intent i = new Intent(this, openpush_service.class);
		startService(i);

		finish( );
	}

}
