
package com.messagepush.push ;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.util.Log ;

public class boot_completed extends BroadcastReceiver
{
	public void onReceive(Context context, Intent intent)
	{
		if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED"))
		{
			Intent i = new Intent(context, openpush_service.class);
			context.startService(i);
		}
	}
}


