package com.messagepush.push;

public class json
{

	private static int json_head( byte b[] )
	{
		for( int i=0; i<b.length; i++ )
		if ( b[i] == '{' ) return i ;
		else if( b[i] == ' ' ) ;
		else if( b[i] == '\t' ) ;
		else if( b[i] == '\r' ) ;
		else if( b[i] == '\n' ) ;
		else return 0 ;

		return 0 ;
	}

	private static int json_check_format_0( byte b[], int h )
	{
		int cr = 0 ;
		int st = 0 ;
		int sq = 0 ;

		for( int i=h; i<b.length; i++ )
		if ( b[i] == '\\' ) i++ ;
		else if( b[i] == '"' ) cr ^= 1 ;
		else if( cr == 1 ) ;
		else if( b[i] == '{' ) st ++ ;
		else if( b[i] == '[' ) sq ++ ;
		else if( b[i] == ']' ) sq -- ;
		else if( b[i] == '}' )
		{
			if( st == 0 ) return 0 ;

			st -- ;

			if( st == 0 )
			{
				if( sq == 0 )
				return i+1 ;
				else
				return 0 ;
			}
		}

		return 0 ;
	}

	public static String check_format( String buf )
	{
		byte[] b = buf.getBytes( );
		int h = 0 ;

		if( b[0] != '{' )
		{
			h = json_head(b);
			if( h == 0 ) return null ;
		}

		int e = json_check_format_0(b,h);
		if( e == 0 ) return null ;

		e = json_struct_end(b,h);
		if( e == 0 ) return null ;
		return new String(b,h,e-h) ;
	}

	private static int json_struct_end( byte b[], int p)
	{
		p++ ;
		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_struct_end(b,p);
		if( b[p] == '}' ) return p+1;

		// field
		if( b[p] != '"' ) return 0;
		p = json_string_end(b,p) ;
		if( p == 0 ) return 0 ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] != ':' ) return 0;
		p ++ ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;

		// value
		if( b[p] == '{' )
		p = json_struct_end(b,p) ;
		else if( b[p] == '[' )
		p = json_sequence_end(b,p) ;
		else if( b[p] == '"' )
		p = json_string_end(b,p) ;
		else
		p = json_value_end(b,p) ;

		if( p == 0 ) return 0 ;

		// end

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_struct_end(b,p);
		if( b[p] == '}' ) return p+1 ;
		return 0 ;

	}

	private static int json_sequence_end( byte b[], int p)
	{
		p++ ;
		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_sequence_end(b,p);
		if( b[p] == ']' ) return p+1 ;

		// value
		if( b[p] == '{' )
		p = json_struct_end(b,p) ;
		else if( b[p] == '[' )
		p = json_sequence_end(b,p) ;
		else if( b[p] == '"' )
		p = json_string_end(b,p) ;
		else
		p = json_value_end(b,p) ;

		if( p == 0 ) return 0 ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_sequence_end(b,p);
		if( b[p] == ']' ) return p+1 ;
		return 0 ;
	}

	private static int json_string_end( byte b[], int p)
	{
		for( p++; p<b.length; p++ )
		if ( b[p] == '\\' ) p++ ;
		else if ( b[p] == '"'  ) return p+1 ;
		return 0;
	}

	private static int json_value_end( byte b[], int p)
	{
		if( memcmp( b,p,"true") )
		return p+4;
		if( memcmp( b,p,"false") )
		return p+5;

		for( ; p<b.length; p++ )
		if ( b[p] >='0' && b[p] <= '9' ) ;
		else return p ;

		return 0 ;
	}

	private static boolean memcmp( byte[] a, int af, String s )
	{
		byte[] b = s.getBytes( );
		int size = b.length ;
		int bf = 0 ;

		for( int i = 0 ; i<size; i++ )
		if ( a[af+i] == b[bf+i] ) ;
		else return false ;
		return true ;
	}

	private static boolean memcmp( byte[] a, int af, byte[] b, int bf, int size )
	{
		for( int i = 0 ; i<size; i++ )
		if ( a[af+i] == b[bf+i] ) ;
		else return false ;
		return true ;
	}

	private static int json_check_field_end( byte b[], int p, byte f[] )
	{

		p++ ;
		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_check_field_end(b,p,f);
		if( b[p] == '}' ) return 0 ;

		if( b[p] != '"' ) return 0;

		int ff = p ;
		p = json_string_end(b,p) ;
		if( p == 0 ) return 0 ;

		int fn = f.length;
		if( 1+fn+1 == p-ff )
		if( memcmp( b,ff+1,f,0,fn ) )
		return p ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] != ':' ) return 0;
		p ++ ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;

		// value
		if( b[p] == '{' )
		p = json_struct_end(b,p) ;
		else if( b[p] == '[' )
		p = json_sequence_end(b,p) ;
		else if( b[p] == '"' )
		p = json_string_end(b,p) ;
		else
		p = json_value_end(b,p) ;

		if( p == 0 ) return 0 ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] == ',' ) return json_check_field_end(b,p,f);
		if( b[p] == '}' ) return 0 ;
		return 0 ;

	}


	public static boolean check_field ( String buf, String field )
	{
		byte[] b = buf.getBytes( );
		byte[] f = field.getBytes( );

		if( b[0] != '{' ) return false ;

		int p = json_check_field_end(b,0,f);
		if( p == 0 ) return false ;
		return true ;
	}

	public static String  get_field( String buf, String field )
	{
		byte[] b = buf.getBytes( );
		byte[] f = field.getBytes( );

		if( b[0] != '{' ) return null ;

		int p = json_check_field_end(b,0,f);
		if( p == 0 ) return null ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
		if( b[p] != ':' ) return null;
		p ++ ;

		while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;

		int v = p ;

		if( b[p] == '{' )
		p = json_struct_end(b,p) ;
		else if( b[p] == '[' )
		p = json_sequence_end(b,p) ;
		else if( b[p] == '"' )
		p = json_string_end(b,p) ;
		else
		p = json_value_end(b,p) ;

		if( p == 0 ) return null ;

		int vn = p-v ;

		if( b[v] == '"' )
		return new String(b,v+1,vn-2);
		else
		return new String(b,v,vn);

	}

	public static String  get_sequence( String buf, int index )
	{
		byte[] b = buf.getBytes( );

		if( b[0] != '[' ) return null ;

		int p = 0;

		while(true)
		{
			p++ ;
			while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;

			if( b[p] == ',' )
			{
				if( index == 0 ) return null ;

				index -- ;
				continue ;
			}

			if( b[p] == ']' ) return null ;


			int v = p ;

			// value
			if( b[p] == '{' )
			p = json_struct_end(b,p) ;
			else if( b[p] == '[' )
			p = json_sequence_end(b,p) ;
			else if( b[p] == '"' )
			p = json_string_end(b,p) ;
			else
			p = json_value_end(b,p) ;

			if( p == 0 ) return null ;

			if( index == 0 )
			{
				int vn = p - v ;

				if( b[v] == '"' )
				return new String(b,v+1,vn-2);
				else
				return new String(b,v,vn);
			}

			index -- ;

			while( b[p] == ' ' || b[p] == '\t' || b[p] == '\r' || b[p] == '\n' ) p ++ ;
			if( b[p] == ',' ) continue ;
			if( b[p] == ']' ) return null ;
		}
	}

	public static String  encode( String buf )
	{
		byte[] b = buf.getBytes( );
		byte[] c = new byte[b.length*2];

		int n = 0 ;
		for( int i=0; i<b.length; i++ )
		{
			if( b[i] == '\\'|| b[i] == '"' )
			c[n++] = '\\' ;

			c[n++] = b[i] ;
		}
		return new String(c,0,n);
	}

	public static String  decode( String buf )
	{
		byte[] b = buf.getBytes( );
		byte[] c = new byte[b.length];

		int n = 0 ;
		for( int i=0; i<b.length; i++ )
		{
			if( b[i] == '\\' ) i++ ;
			c[n++] = b[i] ;
		}
		return new String(c,0,n);
	}


}
