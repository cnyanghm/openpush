
package com.messagepush.push ;



import android.app.Service;
import android.app.AlarmManager;
import android.app.PendingIntent;

import android.os.IBinder;
import android.os.Handler;
import android.os.Message;
import android.os.Build ;
import android.os.SystemClock;

import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException ;

import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.ConnectivityManager ;
import android.net.NetworkInfo ;
import android.net.Network ;

import java.lang.Thread;
import java.lang.Runnable;

import java.net.InetAddress ;
import java.net.DatagramSocket ;
import java.net.DatagramPacket ;
import java.net.SocketException ;
import java.net.UnknownHostException ;

import java.io.IOException ;
import java.io.InterruptedIOException ;

import java.util.UUID;
import java.util.Date;
import java.util.Calendar;
import java.util.List ;
import java.util.ArrayList ;

import android.util.Log ;

public class openpush_service extends Service implements Runnable
{
	private static final String TAG = "OpenPush" ;
    private static final String profile = "openpush_service" ;

	private static final String OPENPUSH_MESSAGE = "OPENPUSH.MESSAGE";

	// 消息推送地址
	// URL for push a message
	private static final String push_server="http://push.headcall.com/openpush/";

	// 注册地址
	// address and port of the login server
	private static final String login_server_init = "push.headcall.com:6100" ;
	private static final int    login_default_port = 6100 ;

	///////////////////////////////////////////////////////////////////

	private String token ;		// 设备编码  device ID
	private String[] pname ;	// app包名列表 list for all app using this service
	private int pname_max ;		// 列表长度 list length max
	private int pname_use ;		// 有效长度 list length used

	private String applist ;	// app 列表, list all app
	private boolean network_ready ; // 网络状态 network status

	private Handler handler ;	// 网络线程向主线程传递数据 used for receiving data from networking thread
	private static int what_message = 2016;
	private static int what_new_token = 2018;

    public void onCreate()
    {
		super.onCreate();

		// 读入配置
		// read profile from flash
		read_profile( ) ;

		// 接收网络线程的消息
		// receive data from networking thread
		handler = new Handler()
		{
			public void handleMessage(Message msg)
			 {
				if( msg.what == what_message )
				{
					// 推送消息
					// get a push message
					get_message( (String) msg.obj ) ;
					return ;
				}

				if( msg.what == what_new_token )
				{
					// 改变 token
					// token changed
					get_new_token( (String) msg.obj ) ;
					return ;
				}

				super.handleMessage(msg);
			}
		};

		// 近期接收的消息列表 防止重复接收
		// message list to provent receive repeated message
        msg_received = new ArrayList<msg_record>();

		// 如果 网络准备好, 就开始登录
		// if the network ready, let's start networking
		network_ready = check_network_ready( ) ;
		if( network_ready )
		login_start( ) ;
		else
		socket_timeout = 0 ;

    }

    private void set_alarm( long timeout )
    {
		Intent i=new Intent(this,event_listener.class);
		i.setAction("OPENPUSH.ALARM");
		PendingIntent pi=PendingIntent.getBroadcast(this, 0, i, 0);
		AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
		am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, timer()+timeout, pi);
	}

	public int onStartCommand(Intent intent, int flags, int startId)
	{
		on_start(intent);

		synchronized( this )
		{
			if( socket_timeout != 0 )
			if(  timer( ) - ( socket_timeout + 2000 ) > 0 )
			login_again( );
		}


		return START_STICKY;
	}

    private void on_start(Intent intent)
	{
		if( intent == null ) return ;

		// app 注册
		// app register
		String packname = intent.getStringExtra("packname");
		if( packname != null )
		{
			get_register( packname );
			return ;
		}

		// 系统消息, 有包被卸载, 看看是不是我们的 app
		// one app removed, is it our app ?
		packname = intent.getStringExtra("package_removed");
		if( packname != null )
		{
			for( int i=0; i<pname_use; i++ )
			if ( packname.equals( pname[i] ) )
			{
				pname[i] = null ;

				synchronized( this )
				{
					save_profile( );
					read_profile( );
					login_again( );
				}

				return ;
			}
			return ;
		}

		// 其它情况, 检查一下网络
		// check the network status in other cases
		{
			boolean ready = check_network_ready( ) ;
			if( network_ready != ready )
			{
				network_ready = ready ;

				if( network_ready )
				login_start( ) ;
				else
				login_stop( );
			}
		}
	}

	public void onDestroy()
	{
		if( network_ready )
		login_stop( );

		msg_received = null ;

		super.onDestroy();

		// 如果本服务被系统卸载, 稍后重新启动它
		// restart it if removed
		set_alarm(1000);
	}

    public IBinder onBind(Intent intent)
    {
        return null;
    }

    ////////////////////////////////////////////////////////////////////

	// 清除配置
	// clear the profile
    private void clear_profile( )
    {
		SharedPreferences sp = getSharedPreferences ( profile, Context.MODE_PRIVATE );
		SharedPreferences.Editor editor = sp.edit();
		editor.clear( );
		editor.commit();
	}

	// 读取配置
	// read the profile
    private void read_profile( )
	{
		SharedPreferences sp = getSharedPreferences ( profile, Context.MODE_PRIVATE );

		token = sp.getString( "token", null );

		if( token == null )
		{
			make_token_init( ) ;

			SharedPreferences.Editor editor = sp.edit();
			editor.putString("token", token );
			editor.commit();
		}

		pname_use = pname_max = 1024 ;
		pname = new String[pname_max];

		for( int i=0; i <pname_max; i++ )
		{
			pname[i] = sp.getString( "pname"+i, null );

			if( pname[i] == null )
			{
				pname_use = i ;

				for( i++; i <pname_max; i++ )
				pname[i] = null ;
			}
			else
			{
				if( ! check_pname( pname[i] ) )
				pname[i] = null ;
			}

		}


		String s = "" ;
		for( int i=0; i<pname_use; i++ )
		if ( pname[i] != null )
		s += "\""+pname[i]+"\",";
		if( s.length( ) > 0 )
		s = s.substring(0,s.length()-1);

		applist = s ;

	}


	// 初始化 token
	// initilize the token using wifi mac
	private void make_token_init( )
	{
		//token = UUID.randomUUID();

		WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		WifiInfo info = wifi.getConnectionInfo();
		String mac_s = info.getMacAddress();

		byte[] mac_b = mac_s.getBytes( );
		byte[] mac_c = new byte[12];

		mac_c[0] = mac_b[0] ;
		mac_c[1] = mac_b[1] ;
		mac_c[2] = mac_b[3] ;
		mac_c[3] = mac_b[4] ;
		mac_c[4] = mac_b[6] ;
		mac_c[5] = mac_b[7] ;
		mac_c[6] = mac_b[9] ;
		mac_c[7] = mac_b[10] ;
		mac_c[8] = mac_b[12] ;
		mac_c[9] = mac_b[13] ;
		mac_c[10] = mac_b[15] ;
		mac_c[11] = mac_b[16] ;

		token = new String(mac_c);
		token = "romx" + token ;
		// 这里 "romx" 是品牌名称, 厂商应该更换为自己的名称
		// 便于服务器识别手机品牌
		// here "romx" is the vendor name. change it for yourself.
	}


	// 保存配置
	// save the profile
	private void save_profile( )
	{
		SharedPreferences sp = getSharedPreferences ( profile, Context.MODE_PRIVATE );

		SharedPreferences.Editor editor = sp.edit();
		editor.clear( );
		editor.putString("token", token );

		int n = 0 ;
		for( int i=0; i <pname_use; i++ )
		if ( pname[i] != null )
		{
			editor.putString( "pname"+n, pname[i] );
			n++ ;
		}

		editor.commit();
		sp=null;
	}


	// 检查 app 存在
	// check if the app exist
	private boolean check_pname( String packname )
	{
		try
		{
			PackageManager pm = getPackageManager();
			pm.getPackageInfo(packname, PackageManager.GET_ACTIVITIES);
			return true;
        }
        catch (NameNotFoundException e)
        {
            return false;
        }
	}

	// 检查网络
	// check the network status
	private boolean check_network_ready( )
    {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP)
		return check_network_ready_old( ) ;


        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null )
        {

			Network[] networks = cm.getAllNetworks() ;

			if (networks != null )
			{
				for(int i = 0; i < networks.length; i++)
				if (cm.getNetworkInfo(networks[i]).getState() == NetworkInfo.State.CONNECTED)
				return true;
			}

		}

		return false;
    }

    private boolean check_network_ready_old( )
    {
		// for android below level LOLLIPOP(21)

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null )
        {

			NetworkInfo[] networkInfo = cm.getAllNetworkInfo();

			if (networkInfo != null )
			{
				for (int i = 0; i < networkInfo.length; i++)
				if (networkInfo[i].getState() == NetworkInfo.State.CONNECTED)
				return true;
			}
		}

		return false;
    }


    ////////////////////////////////////////////////////////////////////
    // app 注册, 告诉它 ( server, token )
    // app register here, tell it with ( server, token )
    private void get_register( String packname )
    {
		if( ! check_pname( packname ) )
		return ;

		int found = 0 ;
		for( int i=0; i<pname_use; i++ )
		if ( packname.equals( pname[i] ) )
		{
			found = 1 ;
			break ;
		}

		if ( found == 0 )
		for( int i=0; i<pname_max; i++ )
		if ( pname[i] == null )
		{
			pname[i] = packname ;

			if( pname_use < i+1 )
			pname_use = i+1 ;

			synchronized( this )
			{
				save_profile( );
				read_profile( );
				login_again( );
			}

			found = 1 ;
			break ;
		}

		if( found == 0 )
		{
			Log.e(TAG, "too many app clients" );
		}
		else
		{

			Intent t=new Intent( OPENPUSH_MESSAGE );
			t.setPackage(packname);
			t.putExtra("server", push_server);
			t.putExtra("token", token);
			t.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
			sendBroadcast(t);
		}

	}

	// 网络消息, 转发给指定 app
	// get a message from push server, forward it to proper app
    private void get_message( String message )
    {
			String packname = json.get_field(message,"packname");

			if( packname != null )
			for( int i=0; i<pname_use; i++ )
			if ( packname.equals( pname[i] ) )
			{
				if( check_pname( packname ) )
				{
					Intent t=new Intent( OPENPUSH_MESSAGE );
					t.setPackage(packname);
					t.putExtra("message", message);
					t.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
					sendBroadcast(t);
				}

				return ;
			}

	}

	// 服务器要求我们改变 token, 通知所有 app
	// the push server changes our token, inform all app
	private void get_new_token( String new_token )
    {

		synchronized( this )
		{
			token = new_token ;

			save_profile( );
			read_profile( );
			login_again( );
		}

		for( int i=0; i<pname_use; i++ )
		if ( pname[i] != null )
		{
			Intent t=new Intent( OPENPUSH_MESSAGE );
			t.setPackage(pname[i]);
			t.putExtra("server", push_server);
			t.putExtra("token", token);
			t.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
			sendBroadcast(t);
		}
	}

    ////////////////////////////////////////////////////////////////////
	// 网络代码
	// networking code
    ////////////////////////////////////////////////////////////////////

	// 近期接收的消息列表 防止重复接收
	// message list to provent receive repeated message
	private class msg_record
	{
		public String content ;
		public long received ;
	} ;
	private List<msg_record> msg_received ;

	// 重复发送间隔
	// interval of repeat sending
	private static final int timeout_init = 120 ; // s
	private static final int sending_interval = 10000 ; // ms

	// 线程
	// networking thread
	private int working ;
	private Thread mThread ;

	private DatagramSocket socket  ;
	private String login_server ;	 // 登录服务器地址和端口  address and port of the login server
	private InetAddress login_addr ; // 地址 address
	private int   login_port ;		 // 端口 port

	private int   login_sending ;	// 0-休息 1-正在发送 0-sleep 1-sending
	private long  login_time ;		// 发送时间 ms, login time last time in ms
	private long  login_timeout ;	// 登录间隔 s,  login time next time in second
	private String login_id ;		// 登录编号 每次增加, login id last time, increased each time

	private long  socket_timeout ;	// socket receive timeout
    ////////////////////////////////////////////////////////////////////

	// 开始登录
	// start networking
	private synchronized void login_start( )
	{
		try	{ socket = new DatagramSocket( ); }
		catch (Exception e) { }


		working = 1 ;
		mThread = new Thread( this ) ;
		mThread.start( );
	}

	// 结束登录
	// stop networking
	private synchronized void login_stop( )
	{
		working = 0 ;
		socket.close();
		try { mThread.join( ); }
		catch (Exception e) { }
		mThread = null ;
	}

	// 重新登录
	// make a login again
	private void login_again( )
	{
		if( network_ready )
		{
			login_stop(  );
			login_start( );
		}
	}
    ////////////////////////////////////////////////////////////////////
	// help functions
    ////////////////////////////////////////////////////////////////////
    // 返回时间秒 get time in second
	private static long time( )
	{
		long GMT_2000_1_1 = 0x386d4380 ;
		long gmt = (new Date()).getTime()/1000;
		return gmt - GMT_2000_1_1 ;
	}
	//返回时间毫秒 get time in ms
	private static long timer( )
	{
		return SystemClock.elapsedRealtime() ;
		//return System.currentTimeMillis( ) ;
	}
	////////////////////////////////////////////////////////////////////
	// 网络线程 networking thread

	public void run()
	{

		byte data[] = new byte[2048];

		login_server = login_server_init ;
		login_addr = null ;
		login_port = 0 ;

		login_sending = 1 ;
		login_time = 0 ;
		login_timeout = timeout_init ;
		login_id = null;

		socket_timeout = 0 ;

		while( working > 0 )
		{

			long now = timer( ) ;

			login( now );

			try
			{

				long waiting ;

				if( login_sending == 0 )
				{
					if( applist.length( ) == 0 )
					waiting = 0 ;
					else
					{
						waiting = login_time + login_timeout*1000 - 2*sending_interval - now ;

						if( waiting > 2000 )
						set_alarm( waiting + 3000 );
					}
				}
				else
				{
					waiting = login_time + sending_interval - now ;
				}

				socket_timeout = now + waiting ;

				socket.setSoTimeout((int)waiting);

				DatagramPacket packet = new DatagramPacket(data, data.length);

				socket.receive(packet);

				socket_timeout = 0 ;

				InetAddress addr = packet.getAddress() ;
				int port = packet.getPort() ;

				int length = packet.getLength() ;

				if( length > 0 )
				{
					String content = new String( data, 0, length );
					receive_message( content, addr, port );
				}
			}
			catch (InterruptedIOException e) {  } // timeout
			catch (SocketException e) { }
			catch (IOException e) { }

			socket_timeout = 0 ;
		}

	}


	// 定期登录
	// periodic login
	private synchronized void login( long now )
	{

		//long now = timer( ) ;

		if( login_sending == 0 )
		{
			if( applist.length( ) == 0 )
			return ;

			if( login_time + login_timeout*1000 - 2*sending_interval - now > 0 )
			return ;

			login_sending = 1 ;
			login_time = 0 ;
		}
		else
		{
			if( login_time + sending_interval - now > 0 )
			return ;
		}

		// send login
		{
			if( login_time == 0 )
			login_id = ""+time( );

			login_time = now ;

			if( login_addr == null )
			try
			{
				String[] a = login_server.split( ":" );

				if( a.length >= 1 )
				login_addr = InetAddress.getByName( a[0] );

				if( a.length == 2 )
				login_port =  Integer.parseInt(a[1]);
				else
				login_port =  login_default_port ;

			}
			catch (Exception e) { login_addr = null; }

			if( login_addr == null ) return ;

			try
			{
				String login_m = "{" ;
				login_m += "\"loginID\":\"" + login_id + "\"," ;
				login_m += "\"token\":\"" + token + "\"," ;
				login_m += "\"timeout\":" + login_timeout + "," ;
				login_m += "\"applist\":["+applist+"]}" ;

				byte data[] = login_m.getBytes();
				DatagramPacket packet = new DatagramPacket(data, data.length, login_addr, login_port );

				socket.send(packet);

			} catch (Exception e) {  }

		}
	}

	// 接收登录回复
	// get login ack
	private void receive_login_ack( String content )
	{

		String loginID = json.get_field(content,"loginID");
		if( loginID == null ) return ;
		String rtoken = json.get_field(content,"token");
		if( rtoken == null ) return ;

		if( !loginID.equals(login_id) ) return ;
		if( !rtoken.equals(token) ) return ;

		login_sending = 0 ;

		String error = json.get_field(content,"error");
		if( error != null )
		{
			Log.e(TAG, error);
			return ;
		}

		String redirect = json.get_field(content,"redirect");
		if( redirect != null )
		{
			login_server = redirect ;
			login_addr = null ;
			login_port = 0 ;

			login_sending = 1 ;
			login_time = 0 ;
			login_timeout = timeout_init ;

			return ;
		}

		String new_token = json.get_field(content,"new_token");
		if( new_token != null )
		{
			// forward the message to the main thread
			Message message = new Message( ) ;
			message.what = what_new_token ;
			message.obj  = new_token ;
			handler.sendMessage(message);
			return ;
		}

		String timeout = json.get_field(content,"timeout");
		if( timeout != null  )
		login_timeout = Long.parseLong(timeout) ;


	}

	// 接收消息
	// get a message from server
	private void receive_message( String content, InetAddress addr, int port )
	{

		content = json.check_format(content);
		if( content == null ) return ;

		// 看看是不是登录回复
		// is it the login ack ?
		String loginID = json.get_field(content,"loginID");
		if( loginID != null )
		{
			receive_login_ack( content );
			return ;
		}

		// 接收推送消息
		// it is push message
		String messageID = json.get_field(content,"messageID");
		if( messageID == null ) return ;

		String mtoken = json.get_field(content,"token");
		if( mtoken == null ) return ;
		if( ! mtoken.equals( token ) ) return ;

		String packname = json.get_field(content,"packname");
		if( packname == null ) return ;

		try
		{
			// 告诉服务器已经收到
			// tell the server, we have got it.
			String reply = "{" ;
			reply += "\"messageID\":\"" + messageID + "\"," ;
			reply += "\"token\":\"" + token + "\"," ;
			reply += "\"packname\":\"" + packname + "\"," ;
			reply += "}" ;

			byte rdata[] = reply.getBytes();
			DatagramPacket packet = new DatagramPacket(rdata, rdata.length, addr, port);

			socket.send(packet);

		} catch (Exception e) {  }

		// 是不是重复消息
		// check the message if it is repeated
		for(int i = 0; i < msg_received.size(); i++)
		if (msg_received.get(i).content.equals(content) )
		return ;

		long now = timer( ) ;

		// 清除一些旧消息
		// clear the old record
		for(int i = msg_received.size() - 1 ; i>=0;  i-- )
		if (now - msg_received.get(i).received > 60000 )
		msg_received.remove(i);

		// 记录新消息
		// record the new message
		msg_record msg = new msg_record( );
		msg.content = content ;
		msg.received = now ;
		msg_received.add(msg);

		// 转发给主线程
		// forward the message to the main thread
		Message message = new Message( ) ;
		message.what = what_message ;
		message.obj  = content ;
		handler.sendMessage(message);

	}


}

/*//////////////////////////////////////////////////////////////////


报文例子 (基本字段)
datagram examples

	login
	{
		"loginID" : "1234567",
		"token"   : "1234567890abcd",
		"timeout" : 150,
		"applist" : [ "com.headcall.test", "com.microsoft.office"]

		......
	}

	login ack : OK
	{
		"loginID" : "1234567",
		"token"   : "1234567890abcd",
		"timeout" : 150
	}

	login ack : new token
	{
		"loginID" : "1234567",
		"token"   : "1234567890abcd",
		"new_token" : "1231231321313213"
	}

	login ack : redirect
	{
		"loginID" : "1234567",
		"token"   : "1234567890abcd",
		"redirect" : "12.34.56.78:1230"
	}


	message
	{
		"messageID" : "1212321321312",
		"token"     : "1234567890abcd",
		"packname"  : "com.headcall.test",

		......
	}

	message ack
	{
		"messageID" : "1212321321312",
		"token"     : "1234567890abcd",
		"packname"  : "com.headcall.test",
	}

安全通讯

	login { } 中可以加入 认证信息

	message{  } 由 app 加入认证, 消息系统不需要认证它
	消息系统并不实际处理这个消息(例如显示), 可以交给 app 自己防伪

security

	the login{ } can be put in authentication.

	the app can put protection info in the message{ }
	the push system don't process the message, so that
	it don't care for security.

////////////////////////////////////////////////////////////////*/

