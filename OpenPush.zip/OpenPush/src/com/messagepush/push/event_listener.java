
package com.messagepush.push ;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.util.Log ;

public class event_listener extends BroadcastReceiver
{
	public void onReceive(Context context, Intent intent)
	{
		String action = intent.getAction() ;
		if( action == null ) return ;

		//Log.v("OpenPush", action );

		Intent i = new Intent(context, openpush_service.class);

		if (action.equals("android.intent.action.PACKAGE_REMOVED"))
		{
			String packname = intent.getData().getSchemeSpecificPart();
			i.putExtra( "package_removed", packname );
		}

		context.startService(i);

	}
}


