
package com.headcall.test;

import android.app.Activity;

import android.content.Context;
import android.content.Context;
import android.content.Intent;

import android.os.Bundle;

import android.view.View.OnTouchListener;
import android.view.View;
import android.widget.Button;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;

import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.NotificationManager ;
import android.app.Notification ;
import android.app.PendingIntent ;

import android.util.Log ;


public class main extends Activity
implements	View.OnClickListener
{
	private static final String TAG = "TEST" ;

	private Button send ;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);
		send = (Button)findViewById(R.id.send);
		send.setOnClickListener(this);

		// 如果本手机没有这个服务, 就不要显示 send button
		// if the service not existed, dont display the send button
		if( ! openpush_receiver.register( this ) )
		//send.setVisibility(View.GONE);
		finish( );
	}

	public void onClick( View v )
	{
		if( v == send )
		{
			push_test_message( );
		}
	}

	// 转由线程操作网络通讯
	// open a thread for networking
	private void push_test_message( )
	{
		new Thread(new Runnable()
		{
			public void run()
			{
				push_test_message_do( );
			}
		}).start();
	}

	// 推送消息
	//
	// app 应该把自己的推送资料 ( push_server, token ) 传送给 app 消息服务器
	// 消息服务器在需要时向 push_server 发送消息, push_server 转发这个消息给 app
	//
	// 我们在这里演示 向 push_server 发送消息
	//
	// push a message
	//
	// app should upload the ( push_server, token ) to the app message server
	// the app message server use them to send messages to the push_server
	// the later will forward the message to the app
	//
	// here we demo how to send a message to the push_server
	//
	private void push_test_message_do( )
	{
		SharedPreferences sp = getSharedPreferences ( "device_token", Context.MODE_PRIVATE ) ;
		String push_server = sp.getString( "server", null );
		String token  = sp.getString( "token", null );

		// example :
		// push_server = "http://push.headcall.com/openpush/"
		// token = "romx123456789012345678"

		if( push_server == null || token == null )
		{
			Log.v(TAG, "device token not found" );
			return ;
		}

		// 消息采用 json 格式, 一定要有 前 4 个字段 其它内容自定义
		// we adopt the json format for the message. the first 4 fields must be there.
		// other fields may be defined freely.

		String message = "{" ;
		message += "\"token\":\""+token+"\",";
		message += "\"packname\":\""+getPackageName()+"\",";
		message += "\"subject\":\"message\",";
		message += "\"timeout\":120,";
		message += "\"data\":{ \"message\":\"test only\",\"sound\":\"default\"}";
		message += "}";

		// 检测 json 格式
		// check the json format
		{
			try{
			    JSONObject jsonObject = new JSONObject( message );
			    // OK, it is well-formated
			}catch(JSONException e){
			    Log.e(TAG, "error formated : " + message ) ;
			    return ;
			}

		}

		Log.v(TAG, "send..." + message );

		byte[] body = message.getBytes();


        try {

            URL url = new URL(push_server);
			HttpURLConnection http ;

			/*
			///////////////////////////////////////////////////////////
            http = (HttpURLConnection)url.openConnection();
            http.setConnectTimeout(3000);
            http.setDoInput(true);
            http.setDoOutput(true);
            http.setRequestMethod("GET");
            http.setUseCaches(false);
            http.setInstanceFollowRedirects(true);
            http.getResponseCode();
			url = http.getURL( );
			http.disconnect( );
			*/
			////////////////////////////////////////////////////////////
			http = (HttpURLConnection)url.openConnection();
            http.setConnectTimeout(3000);
            http.setDoInput(true);
            http.setDoOutput(true);
            http.setRequestMethod("POST");
            http.setUseCaches(false);
            http.setRequestProperty("Content-Type", "application/json");
            http.setRequestProperty("Content-Length", String.valueOf(body.length));
            http.setInstanceFollowRedirects(false);

            OutputStream out = http.getOutputStream();
            out.write(body);
            out.flush();
			out.close();

			InputStream inputStream = http.getInputStream();

            int response = http.getResponseCode();

            //if( response == http.HTTP_OK )
            {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				byte[] buf = new byte[1024];
				int len = 0;
				try
				{
					while((len = inputStream.read(buf)) != -1)
					byteArrayOutputStream.write(buf, 0, len);
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}

				String output = new String(byteArrayOutputStream.toByteArray());
				Log.v(TAG, "http answer : " + output );
            }

        }
        catch (IOException e)
        {
        }

	}


	public static void make_notification( Context context, String message )
	{
		Intent notificationIntent = new Intent(context, main.class);
		notificationIntent.setAction(Intent.ACTION_MAIN);
		notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
		PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		Notification notification = new Notification.Builder(context)
			.setSmallIcon(R.drawable.icon)
			.setTicker( "--get a message--" )
			.setContentTitle( "--title--" )
			.setContentText( "--message--" )
			.setContentIntent(pendingIntent)
			.build();

		notification.flags |= Notification.FLAG_AUTO_CANCEL;

		int notification_id = 0 ;
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(notification_id,notification);

	}



}
