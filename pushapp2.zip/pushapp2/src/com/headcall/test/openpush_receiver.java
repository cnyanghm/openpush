package com.headcall.test ;

import android.app.ActivityManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;

import android.content.SharedPreferences;

import java.util.List;

import android.util.Log ;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import android.net.Uri;
import android.os.Environment ;

// 功能
// 注册到服务程序
// 接收服务程序的广播
//
// functions
// register to the service
// receive broadcasting from the service

public class openpush_receiver extends BroadcastReceiver
{
	private static final String TAG = "TEST" ;

	// 注册
	// register to the service
	public static boolean register( Context context )
	{
		// 查找服务程序
		// Lookup the service
		Intent i = new Intent( "OPENPUSH.SERVICE" );
		PackageManager pm = context.getPackageManager();
		List<ResolveInfo> list = pm.queryIntentServices(i, 0);
		if( list.size() > 0 )
		{
			// 告诉服务程序本 app 包名
			// tell the service my package name
			i.putExtra( "packname", context.getPackageName() );
			context.startService(i);
			return true ;
		}

		// 不存在这个服务
		// 安装 公共服务
		{
			openpush_install( context );
			return false ;
		}

	}


	// 接收广播
	// receive broadcasting from the service
	public void onReceive(Context context, Intent intent)
	{

		String token = intent.getStringExtra("token");
		if( token != null )
		{
			// 保存 推送资料 ( server, token )
			// save the information ( server, token )

			String push_server = intent.getStringExtra("server");

			SharedPreferences sp = context.getSharedPreferences ( "device_token", Context.MODE_PRIVATE ) ;
			SharedPreferences.Editor editor = sp.edit();
			editor.clear( );
			editor.putString("server", push_server );
			editor.putString("token", token );
			editor.commit();

			return ;

		}

		String message = intent.getStringExtra("message");
		if( message != null )
		{
			// 获取消息 json 格式
			// get a message in json format

			Log.v(TAG, "get message : " + message );

			main.make_notification( context, message ) ;


			return ;
		}

	}

	// 安装 openpush : /assets/OpenPush.apk

	static void openpush_install( Context context )
	{
		try
		{
			String sdcard = Environment.getExternalStorageDirectory().getPath() ;
			String path = sdcard + "/OpenPush.apk" ;

			File file = new File(path);
			file.createNewFile();
			FileOutputStream fout = new FileOutputStream(file);
			InputStream fin = context.getAssets().open("OpenPush.apk");

			byte[] buf = new byte[1024];
			int i = 0;
			while ((i = fin.read(buf)) > 0)
			fout.write(buf, 0, i);

			fin.close();
			fout.close();

  			Uri uri = Uri.fromFile( new File(path) );

			Intent intent = new Intent();
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.setAction(android.content.Intent.ACTION_VIEW);
			intent.setDataAndType(uri, "application/vnd.android.package-archive");
			context.startActivity(intent);

		} catch (IOException e) { }


	}


}
