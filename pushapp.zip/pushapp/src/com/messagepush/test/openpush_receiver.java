package com.messagepush.test ;

import android.app.ActivityManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;

import android.content.SharedPreferences;

import java.util.List;

import android.util.Log ;

// 功能
// 注册到服务程序
// 接收服务程序的广播
//
// functions
// register to the messaging service
// receive broadcasting from the messaging service

public class openpush_receiver extends BroadcastReceiver
{
	private static final String TAG = "TEST" ;


	// 注册
	// register to the messaging service
	public static boolean register( Context context )
	{
		// 查找服务程序
		// Lookup the messaging service
		Intent i = new Intent( "OPENPUSH.SERVICE" );
		PackageManager pm = context.getPackageManager();
		List<ResolveInfo> list = pm.queryIntentServices(i, 0);
		if( list.size() > 0 )
		{
			// 告诉服务程序本 app 包名
			// tell the service my package name
			i.putExtra( "packname", context.getPackageName() );
			context.startService(i);
			return true ;
		}

		// 不存在这个服务
		// this service doesn't exist
		return false ;

	}


	// 接收广播
	// receive broadcasting from the service
	public void onReceive(Context context, Intent intent)
	{


		String token = intent.getStringExtra("token");
		if( token != null )
		{

			// 保存 推送资料 ( server, token )
			// save the information ( server, token )

			String push_server = intent.getStringExtra("server");

			Log.v(TAG, "get token : " + token + "  server : " + push_server );

			SharedPreferences sp = context.getSharedPreferences ( "device_token", Context.MODE_PRIVATE ) ;
			SharedPreferences.Editor editor = sp.edit();
			editor.clear( );
			editor.putString("token", token );
			editor.putString("server", push_server );
			editor.commit();

			return ;

		}

		String message = intent.getStringExtra("message");
		if( message != null )
		{
			// 获取消息 json 格式
			// get a message in json format

			Log.v(TAG, "get message : " + message );

			return ;
		}

	}


}
